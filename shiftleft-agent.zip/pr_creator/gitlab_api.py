
import os
import subprocess
import requests

def create_gitlab_pr(repo_url, repo_name, token, branch, message):
    subprocess.run(f"git clone {repo_url}", shell=True)
    os.chdir(repo_name)
    subprocess.run(f"git checkout -b {branch}", shell=True)
    subprocess.run("git config user.email 'bot@example.com'", shell=True)
    subprocess.run("git config user.name 'SecurityBot'", shell=True)
    subprocess.run("git add .", shell=True)
    subprocess.run(f"git commit -m '{message}'", shell=True)
    subprocess.run(f"git push origin {branch}", shell=True)

    headers = {"PRIVATE-TOKEN": token}
    project_id = requests.get(f"https://gitlab.com/api/v4/projects?search={repo_name}", headers=headers).json()[0]["id"]

    data = {
        "id": project_id,
        "source_branch": branch,
        "target_branch": "main",
        "title": message
    }
    r = requests.post(f"https://gitlab.com/api/v4/projects/{project_id}/merge_requests", headers=headers, data=data)
    print(r.status_code, r.text)
