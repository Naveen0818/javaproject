
def update_dependency(file_path, package_name, new_version):
    with open(file_path, "r") as f:
        lines = f.readlines()

    with open(file_path, "w") as f:
        for line in lines:
            if package_name in line and "<version>" in line:
                f.write(f'    <version>{new_version}</version>\n')
            else:
                f.write(line)
