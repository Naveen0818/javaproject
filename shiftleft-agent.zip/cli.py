
from scanner_interface.parse_fortify import parse_fortify_report
from fix_engine.dependency_updater import update_dependency
from pr_creator.gitlab_api import create_gitlab_pr
import sys
import os

if __name__ == "__main__":
    print("Parsing Fortify scan...")
    issues = parse_fortify_report("sample_fortify_report.json")
    for issue in issues:
        print(issue)

    print("Updating dependency...")
    update_dependency("example/pom.xml", "log4j", "2.17.1")

    print("Creating GitLab PR...")
    create_gitlab_pr(
        repo_url="https://gitlab.com/your-namespace/your-repo.git",
        repo_name="your-repo",
        token=os.getenv("GITLAB_TOKEN"),
        branch="security/bump-log4j",
        message="chore: bump log4j to 2.17.1 due to CVE"
    )
