
import json

def parse_fortify_report(report_path):
    with open(report_path) as f:
        data = json.load(f)

    issues = []
    for issue in data.get("issues", []):
        issues.append({
            "type": issue.get("issue_type"),
            "file": issue.get("file"),
            "line": issue.get("line"),
            "severity": issue.get("severity")
        })
    return issues
